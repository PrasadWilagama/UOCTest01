package Task2;

public class InfoBase {
	
	public static void  printMyInfo() {
		System.out.println("Name is Prasad");
		System.out.println("I am a Developer");
		
	}
	
	public static void  printMyHerosInfo() {
		System.out.println("Name for the my hero is Sampath ");
		System.out.println("He is my Father");
				
	}	

}
