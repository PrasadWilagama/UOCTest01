package Task3;

public class StarPrinter {
	
   static void starprinter(int n) {
	 for (int i = 1; i <=n; i++) {
         int x = i*2+2;
          
         for (int j = 1; j <=x; j++) {
          
             for (int k = 1; k <=j; k++) {
                 System.out.print("*");
             }
             System.out.println("");
         }
		}
		
	}

}
