package Task3;
import java.util.Scanner;
public class MainStarPrinter {

	public static void main(String[] args) {
		 Scanner myObj = new Scanner(System.in);
		    System.out.println("line Number");
		    String line = myObj.nextLine();
		    int n=Integer.valueOf(line);
		    StarPrinter.starprinter(n);
		
	}

}
